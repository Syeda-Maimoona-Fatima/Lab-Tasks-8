#include <stdio.h>
void welcome()
{
    printf("Welcome to the Shopping Store\n");
}
void showMenu(void)
{
    printf("\n1. Rice   Rs.400\n");
    printf("2. Oil    Rs.650\n");
    printf("3. Sugar  Rs.180\n");
    printf("4. Tea    Rs.550\n");
    printf("5. Milk   Rs.280\n");
}
int getPrice(int choice)
{
    if (choice==1)
        return 400;
    else if (choice==2)
        return 650;
    else if (choice==3)
        return 180;
    else if (choice==4)
        return 550;
    else
    return 280;
}
int calculateItemPrice(int price, int quantity)
{
    return price*quantity;
}
int calculateSubtotal(int qty[])
{
    int i,sum=0;
    for (i=0;i<5;i++)
    {
        sum=sum+calculateItemPrice(getPrice(i+1), qty[i]);
    }
    return sum;
}
int calculateDiscount(int subtotal)
{
    if (subtotal>=5000)
        return subtotal/10;
    else
    return 0;
}
int calculateFinalBill(int subtotal, int discount)
{
    return subtotal-discount;
}
void displayReceipt(int qty[], int subtotal, int discount, int total)
{
    int i;
    char names[5][6]={"Rice","Oil","Sugar","Tea","Milk"};
    printf("\nSHOPPING RECEIPT\n");
    for (i=0;i<5;i++)
    {
        if (qty[i]>0)
            printf("%s x %d @ Rs.%d = Rs.%d\n",names[i],qty[i],getPrice(i+1),calculateItemPrice(getPrice(i+1), qty[i]));
    }
    printf("Subtotal: Rs.%d\n",subtotal);
    printf("Discount: Rs.%d\n",discount);
    printf("Final payable amount: Rs.%d\n",total);
}
char askContinue(void)
{
    char c;
    printf("want to continue shopping? (yes(Y) or no(N)): ");
    scanf(" %c",&c);
    return c;
}
int main()
{
    int qty[5]={0,0,0,0,0};
    int choice,q,subtotal,discount,total;
    char again;
    welcome();
    do{
        showMenu();
        printf("Enter product number: ");
        scanf("%d",&choice);
        if (choice>=1 && choice<=5)
        {
            printf("Enter quantity: ");
            scanf("%d",&q);
            if (q>0)
                qty[choice-1]=qty[choice-1]+q;
            else
                printf("error--quantity must be greater than zero\n");
        }
        else
            printf("error--invalid product number\n");
        again = askContinue();
    } while (again=='Y' || again=='y');
    subtotal=calculateSubtotal(qty);
    discount=calculateDiscount(subtotal);
    total=calculateFinalBill(subtotal, discount);
    displayReceipt(qty, subtotal, discount, total);
    return 0;
}
