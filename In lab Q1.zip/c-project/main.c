#include <stdio.h>
void welcome()
{
    printf("Welcome to the ATM System\n");
}
void displayAmount(int amount)
{
    printf("Withdrawal amount is Rs.%d\n",amount);
}
int getWithdrawalLimit(void)
{
    return 50000;
}
int calculateBalance(int balance, int amount)
{
    return balance-amount;
}
int checkWithdrawal(int balance, int amount, int limit)
{
    if (amount>0 && amount<=balance && amount<=limit)
        return 1;
    else
    return 0;
}
int main()
{
    int balance, amount, limit;
    char again;
    welcome();
    printf("Enter current account balance: Rs. ");
    scanf("%d",&balance);
    limit = getWithdrawalLimit();
    printf("Maximum withdrawal limit: Rs. %d\n",limit);
    do{
        printf("\nEnter amount to withdraw: Rs. ");
    scanf("%d", &amount);
    displayAmount(amount);
    if (checkWithdrawal(balance,amount,limit)==1)
    {
        balance = calculateBalance(balance, amount);
        printf("Withdrawal successful\n");
        printf("Remaining balance: Rs. %d\n", balance);
    }
    else
    {
        printf("Invalid withdrawal\n");
        if (amount<=0)
            printf("error--amount must be greater than zero\n");
        else if (amount>balance)
            printf("error--insufficient balance\n");
        else
            printf("error--amount exceeds the withdrawal limit\n");
        printf("Balance: Rs.%d\n", balance);
    }
   printf("want to make another withdrawal? (yes(Y) or no(N)): ");
        scanf(" %c", &again);
    } while (again=='y' || again== 'Y');
    printf("\nBalance: Rs.%d\n", balance);
    return 0;
}
